# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['flasksqlamypy']

package_data = \
{'': ['*']}

install_requires = \
['flask-sqlalchemy>=2.4.0,<3.0.0',
 'mypy>=0.950,<0.951',
 'sqlalchemy-stubs>=0.4,<0.5']

setup_kwargs = {
    'name': 'flask-sqlalchemy-stubs',
    'version': '0.0.1',
    'description': 'Stubs for flask-sqlalchemy',
    'long_description': 'Mypy plugin and stubs for Flask-SQLAlchemy\n=====================\n\nPlease check example directory.\n\n*Important*: you need to enable the plugin in your mypy config file, **and pycharm doesn\'t support mypy plugin.**\n\n::\n\n  [mypy]\n  plugins = flasksqlamypy\n\nExapmle\n---------------\n::\n\n  from typing import TYPE_CHECKING\n  from flask_sqlalchemy import SQLAlchemy\n\n  db = SQLAlchemy()\n  \n  if TYPE_CHECKING:\n      from flask_sqlalchemy.model import Model\n\n      BaseModel = db.make_declarative_base(Model)\n  else:\n      BaseModel = db.Model\n\n  class User(BaseModel):\n      __tablename__ = \'users\'\n      id = db.Column(db.Integer, primary_key=True)\n      name = db.Column(db.String)\n\n  user = User(id=42, name=42)  # Error: Incompatible type for "name" of "User"\n                               # (got "int", expected "Optional[str]")\n  user.id  # Inferred type is "int"\n  User.name  # Inferred type is "Column[Optional[str]]"\n\nInstall\n-----------------\n::\n\n  pip install git+https://github.com/ssfdust/flask-sqlalchemy-stubs.git \n\nJedi Completion Tricks\n----------------\n\nYou can define a classmethod with `self` typed, which makes jedi completion to\nwork. Please check examples/sample.py for the entire example.\n\n\n.. image:: ./assets/jedi.gif\n',
    'author': 'ssfdust',
    'author_email': 'ssfdust@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
}


setup(**setup_kwargs)
